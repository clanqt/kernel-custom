#echo ~I0100 > /dev/printer
echo ~E0028Bharat PetroleumRLC~2! > /dev/printer
echo ~E0032OUTLET : BP KAKKANADRSL~2! > /dev/printer
echo ~E0030ADDRESS: PADAMUGALRSL~2! > /dev/printer
echo ~E0031PH. NUM: 8967398124RSL~2! > /dev/printer
echo ~E0046----------------------------------RSL~2! > /dev/printer
echo ~E0026BILL NO: 31982RSL~2! > /dev/printer
echo ~E0030Data\&Time:15\\02\\17RSL~2! > /dev/printer
echo ~E0031VEHICLE: KL 40 M 97RSL~2! > /dev/printer
echo ~E0025Pump\&Noz:03-2RSL~2! > /dev/printer
echo ~E0026PRODUCT:PETROLRSL~2! > /dev/printer
echo ~E0027RATE	:74.239RSL~2! > /dev/printer
echo ~E0025VOLUME :13.47RSL~2! > /dev/printer
echo ~E0024AMOUNT :1000RSL~2! > /dev/printer
echo ~E0026DENSITY :734.7RSL~2! > /dev/printer
echo ~E0025PRESENT :1000RSL~2! > /dev/printer
echo ~E0046----------------------------------RSL~2! > /dev/printer
echo ~E0046----------------------------------RSL~2! > /dev/printer
echo ~E0034THANK YOU! VISIT AGAINRSC~2! > /dev/printer
echo ~R0050 > /dev/printer

echo ~R0200 > /dev/printer
