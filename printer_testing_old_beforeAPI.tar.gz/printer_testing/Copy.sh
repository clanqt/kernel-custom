cp printer.ko ../7520_3.5_Inch/Filesystem/MATCHBOX_14112016/opt/daemon_files/
cp printer.ko ../7510_2.8_Inch/Filesystem/MATCHBOX_14112016/opt/daemon_files/
